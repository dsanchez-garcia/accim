.. accim documentation master file, created by
   sphinx-quickstart on Sun Feb 21 14:22:20 2021.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

.. image:: images/accim_logo_nohatch_w-header.svg
  :width: 900

Welcome to accim's documentation!
=================================

.. toctree::
   :maxdepth: 3
   :caption: Contents:

   readme
   installation
   how to use
   examples
   additional scripts
   troubleshooting

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
