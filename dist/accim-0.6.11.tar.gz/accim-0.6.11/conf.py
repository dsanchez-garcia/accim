source_parsers = {
    '.md': 'recommonmark.parser.CommonMarkParser',
}

source_suffix = ['.rst', '.md']


extensions = [
    'sphinx_markdown_tables',
]