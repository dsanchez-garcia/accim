"""Classes for ACCIM SingleZone and MultipleZone."""


class ACCIMobj():
    """ACCIM Object."""

    from os import listdir
    import numpy

    from sim.ACCIM_IDFgeneration import inputdataSingleZone
    from sim.ACCIM_IDFgeneration import inputdataMultipleZone
    from sim.ACCIM_IDFgeneration import genIDFSingleZone
    from sim.ACCIM_IDFgeneration import genIDFMultipleZone

    from sim.ACCIM_Base import setComfFieldsPeople
    from sim.ACCIM_Base import addOpTempTherm
    from sim.ACCIM_Base import addBaseSchedules
    from sim.ACCIM_Base import setAvailSchOn
    from sim.ACCIM_Base import saveACCIM

    from sim.ACCIM_Base_EMS import addEMSProgramsBase
    from sim.ACCIM_Base_EMS import addEMSPCMBase
    from sim.ACCIM_Base_EMS import addEMSOutputVariableBase
    from sim.ACCIM_Base_EMS import addOutputVariablesTimestep
    from sim.ACCIM_Base_EMS import addSimplifiedOutputVariables

    pass


class ACCIMobj_SingleZone_ep91 (ACCIMobj):
    """SingleZone ACCIM object."""

    from sim.ACCIM_SingleZone import addForscriptSchSingleZone

    from sim.ACCIM_SingleZone_EMS import addGlobVarListSingleZone
    from sim.ACCIM_SingleZone_EMS import addEMSSensorsSingleZone
    from sim.ACCIM_SingleZone_EMS import addEMSActuatorsSingleZone
    from sim.ACCIM_SingleZone_EMS import addEMSProgramsSingleZone
    from sim.ACCIM_SingleZone_EMS import addOutputVariablesSingleZone

    def __init__(self, filename_temp):
        from eppy import modeleditor
        from eppy.modeleditor import IDF

        iddfile = 'C:/EnergyPlusV9-1-0/Energy+.idd'
        IDF.setiddname(iddfile)

        fname1 = filename_temp+'.idf'
        self.idf0 = IDF(fname1)
        self.idf0.savecopy(filename_temp+'_pymod.idf')

        self.filename = filename_temp+'_pymod'
        fname1 = self.filename+'.idf'
        self.idf1 = IDF(fname1)
        self.filename = filename_temp+'_pymod'

        print(self.filename)

        self.zonenames_orig = ([zone.Name for zone in self.idf1.idfobjects['ZONE']])
        # print(self.zonenames_orig)

        self.zonenames = ([sub.replace(':', '_') for sub in ([zone.Name for zone in self.idf1.idfobjects['ZONE']])])
        # print(self.zonenames)


class ACCIMobj_MultipleZone_ep91 (ACCIMobj):
    """MultipleZone ACCIM object."""

    from sim.ACCIM_MultipleZone import addMultipleZoneSch
    from sim.ACCIM_MultipleZone import addCurveObj
    from sim.ACCIM_MultipleZone import addDetHVACobjEp91
    from sim.ACCIM_MultipleZone import addForscriptSchMultipleZone
    from sim.ACCIM_MultipleZone import checkVentIsOn

    from sim.ACCIM_MultipleZone_EMS import addGlobVarListMultipleZone
    from sim.ACCIM_MultipleZone_EMS import addEMSSensorsMultipleZone
    from sim.ACCIM_MultipleZone_EMS import addEMSActuatorsMultipleZone
    from sim.ACCIM_MultipleZone_EMS import addEMSProgramsMultipleZone
    from sim.ACCIM_MultipleZone_EMS import addEMSOutputVariableMultipleZone
    from sim.ACCIM_MultipleZone_EMS import addOutputVariablesMultipleZone

    def __init__(self, filename_temp):
        from eppy import modeleditor
        from eppy.modeleditor import IDF

        iddfile = 'C:/EnergyPlusV9-1-0/Energy+.idd'
        IDF.setiddname(iddfile)

        fname1 = filename_temp+'.idf'
        self.idf0 = IDF(fname1)
        self.idf0.savecopy(filename_temp+'_pymod.idf')

        self.filename = filename_temp+'_pymod'
        fname1 = self.filename+'.idf'
        self.idf1 = IDF(fname1)
        self.filename = filename_temp+'_pymod'

        print(self.filename)

        self.zonenames_orig = ([zone.Name for zone in self.idf1.idfobjects['ZONE']])
        # print(self.zonenames_orig)

        self.zonenames = ([sub.replace(':', '_') for sub in ([zone.Name for zone in self.idf1.idfobjects['ZONE']])])
        # print(self.zonenames)

        self.windownamelist_orig = ([window.Name for window in self.idf1.idfobjects['AirflowNetwork:MultiZone:Component:DetailedOpening'] if window.Name.endswith('_Win')])
        print(self.windownamelist_orig)
        self.windownamelist_orig_split = ([i.split('_') for i in self.windownamelist_orig])
        # print(self.windownamelist_orig_split)

        self.windownamelist = ([sub.replace(':', '_') for sub in ([window.Name for window in self.idf1.idfobjects['AirflowNetwork:MultiZone:Component:DetailedOpening'] if window.Name.endswith('_Win')])])
        # print(self.windownamelist)


class ACCIMobj_SingleZone_ep94 (ACCIMobj):
    """SingleZone ACCIM object."""

    from sim.ACCIM_SingleZone import addForscriptSchSingleZone

    from sim.ACCIM_SingleZone_EMS import addGlobVarListSingleZone
    from sim.ACCIM_SingleZone_EMS import addEMSSensorsSingleZone
    from sim.ACCIM_SingleZone_EMS import addEMSActuatorsSingleZone
    from sim.ACCIM_SingleZone_EMS import addEMSProgramsSingleZone
    from sim.ACCIM_SingleZone_EMS import addOutputVariablesSingleZone

    def __init__(self, filename_temp):
        from eppy import modeleditor
        from eppy.modeleditor import IDF

        iddfile = 'C:/EnergyPlusV9-4-0/Energy+.idd'
        IDF.setiddname(iddfile)

        fname1 = filename_temp+'.idf'
        self.idf0 = IDF(fname1)
        self.idf0.savecopy(filename_temp+'_pymod.idf')

        self.filename = filename_temp+'_pymod'
        fname1 = self.filename+'.idf'
        self.idf1 = IDF(fname1)
        self.filename = filename_temp+'_pymod'

        print(self.filename)

        self.zonenames_orig = ([zone.Name for zone in self.idf1.idfobjects['ZONE']])
        # print(self.zonenames_orig)

        self.zonenames = ([sub.replace(':', '_') for sub in ([zone.Name for zone in self.idf1.idfobjects['ZONE']])])
        # print(self.zonenames)


class ACCIMobj_MultipleZone_ep94 (ACCIMobj):
    """MultipleZone ACCIM object."""

    from sim.ACCIM_MultipleZone import addMultipleZoneSch
    from sim.ACCIM_MultipleZone import addCurveObj
    from sim.ACCIM_MultipleZone import addDetHVACobjEp94
    from sim.ACCIM_MultipleZone import addForscriptSchMultipleZone
    from sim.ACCIM_MultipleZone import checkVentIsOn

    from sim.ACCIM_MultipleZone_EMS import addGlobVarListMultipleZone
    from sim.ACCIM_MultipleZone_EMS import addEMSSensorsMultipleZone
    from sim.ACCIM_MultipleZone_EMS import addEMSActuatorsMultipleZone
    from sim.ACCIM_MultipleZone_EMS import addEMSProgramsMultipleZone
    from sim.ACCIM_MultipleZone_EMS import addEMSOutputVariableMultipleZone
    from sim.ACCIM_MultipleZone_EMS import addOutputVariablesMultipleZone

    def __init__(self, filename_temp):
        from eppy import modeleditor
        from eppy.modeleditor import IDF

        iddfile = 'C:/EnergyPlusV9-4-0/Energy+.idd'
        IDF.setiddname(iddfile)

        fname1 = filename_temp+'.idf'
        self.idf0 = IDF(fname1)
        self.idf0.savecopy(filename_temp+'_pymod.idf')

        self.filename = filename_temp+'_pymod'
        fname1 = self.filename+'.idf'
        self.idf1 = IDF(fname1)
        self.filename = filename_temp+'_pymod'

        print(self.filename)

        self.zonenames_orig = ([zone.Name for zone in self.idf1.idfobjects['ZONE']])
        # print(self.zonenames_orig)

        self.zonenames = ([sub.replace(':', '_') for sub in ([zone.Name for zone in self.idf1.idfobjects['ZONE']])])
        # print(self.zonenames)

        self.windownamelist_orig = ([window.Name for window in self.idf1.idfobjects['AirflowNetwork:MultiZone:Component:DetailedOpening'] if window.Name.endswith('_Win')])
        print(self.windownamelist_orig)
        self.windownamelist_orig_split = ([i.split('_') for i in self.windownamelist_orig])
        # print(self.windownamelist_orig_split)

        self.windownamelist = ([sub.replace(':', '_') for sub in ([window.Name for window in self.idf1.idfobjects['AirflowNetwork:MultiZone:Component:DetailedOpening'] if window.Name.endswith('_Win')])])
        # print(self.windownamelist)
