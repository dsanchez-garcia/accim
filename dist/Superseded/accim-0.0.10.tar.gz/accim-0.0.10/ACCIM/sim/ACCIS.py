"""
Run any of the functions below to add the ACCIS.

These functions transform fixed setpoint temperature
building energy models into adaptive setpoint temperature energy models
by addingthe Adaptive Comfort Control Implementation Script (ACCIS)
"""


def addAccisSingleZoneep91():
    """Add SingleZone ACCIS."""
    import sim.ACCIM_Main as ACCIM_Main
    from os import listdir

    filelist = ([file for file in listdir() if file.endswith('.idf')
                 and not file.endswith('_pymod.idf')])

    filelist = ([file.split('.idf')[0] for file in filelist])

    for file in filelist:
        z = ACCIM_Main.ACCIMobj_SingleZone_ep91(file)

        z.setComfFieldsPeople()
        z.addOpTempTherm()
        z.addBaseSchedules()
        z.setAvailSchOn()

        z.addForscriptSchSingleZone()

        z.addEMSProgramsBase()
        z.addEMSOutputVariableBase()

        z.addGlobVarListSingleZone()
        z.addEMSSensorsSingleZone()
        z.addEMSActuatorsSingleZone()
        z.addEMSProgramsSingleZone()
        z.addEMSPCMBase()
        z.addOutputVariablesSingleZone()

        z.saveACCIM()

    z = ACCIM_Main.ACCIMobj()
    z.inputdataSingleZone()
    z.genIDFSingleZone()


def addAccisSingleZoneep94():
    """Add SingleZone ACCIS."""
    import sim.ACCIM_Main as ACCIM_Main

    from os import listdir

    filelist = ([file for file in listdir() if file.endswith('.idf')
                 and not file.endswith('_pymod.idf')])

    filelist = ([file.split('.idf')[0] for file in filelist])

    for file in filelist:
        z = ACCIM_Main.ACCIMobj_SingleZone_ep94(file)

        z.setComfFieldsPeople()
        z.addOpTempTherm()
        z.addBaseSchedules()
        z.setAvailSchOn()

        z.addForscriptSchSingleZone()

        z.addEMSProgramsBase()
        z.addEMSOutputVariableBase()

        z.addGlobVarListSingleZone()
        z.addEMSSensorsSingleZone()
        z.addEMSActuatorsSingleZone()
        z.addEMSProgramsSingleZone()
        z.addEMSPCMBase()
        z.addOutputVariablesSingleZone()

        z.saveACCIM()

    z = ACCIM_Main.ACCIMobj()
    z.inputdataSingleZone()
    z.genIDFSingleZone()


def addAccisSingleZoneTimestepEp91():
    """Add SingleZone ACCIS with timestep output data frecuency."""
    import sim.ACCIM_Main as ACCIM_Main

    from os import listdir

    filelist = ([file for file in listdir() if file.endswith('.idf')
                 and not file.endswith('_pymod.idf')])

    filelist = ([file.split('.idf')[0] for file in filelist])

    for file in filelist:
        z = ACCIM_Main.ACCIMobj_SingleZone_ep91(file)

        z.setComfFieldsPeople()
        z.addOpTempTherm()
        z.addBaseSchedules()
        z.setAvailSchOn()

        z.addForscriptSchSingleZone()

        z.addEMSProgramsBase()
        z.addEMSOutputVariableBase()

        z.addGlobVarListSingleZone()
        z.addEMSSensorsSingleZone()
        z.addEMSActuatorsSingleZone()
        z.addEMSProgramsSingleZone()
        z.addEMSPCMBase()
        z.addOutputVariablesSingleZone()
        z.addOutputVariablesTimestep()

        z.saveACCIM()

    z = ACCIM_Main.ACCIMobj()
    z.inputdataSingleZone()
    z.genIDFSingleZone()


def addAccisSingleZoneTimestepEp94():
    """Add SingleZone ACCIS with timestep output data frecuency."""
    import sim.ACCIM_Main as ACCIM_Main

    from os import listdir

    filelist = ([file for file in listdir() if file.endswith('.idf')
                 and not file.endswith('_pymod.idf')])

    filelist = ([file.split('.idf')[0] for file in filelist])

    for file in filelist:
        z = ACCIM_Main.ACCIMobj_SingleZone_ep94(file)

        z.setComfFieldsPeople()
        z.addOpTempTherm()
        z.addBaseSchedules()
        z.setAvailSchOn()

        z.addForscriptSchSingleZone()

        z.addEMSProgramsBase()
        z.addEMSOutputVariableBase()

        z.addGlobVarListSingleZone()
        z.addEMSSensorsSingleZone()
        z.addEMSActuatorsSingleZone()
        z.addEMSProgramsSingleZone()
        z.addEMSPCMBase()
        z.addOutputVariablesSingleZone()
        z.addOutputVariablesTimestep()

        z.saveACCIM()

    z = ACCIM_Main.ACCIMobj()
    z.inputdataSingleZone()
    z.genIDFSingleZone()


def addAccisSingleZoneSimplifiedEp91():
    """Add SingleZone ACCIS with simplified outputs."""
    import sim.ACCIM_Main as ACCIM_Main

    from os import listdir

    filelist = ([file for file in listdir() if file.endswith('.idf')
                 and not file.endswith('_pymod.idf')])

    filelist = ([file.split('.idf')[0] for file in filelist])

    for file in filelist:
        z = ACCIM_Main.ACCIMobj_SingleZone_ep91(file)

        z.setComfFieldsPeople()
        z.addOpTempTherm()
        z.addBaseSchedules()
        z.setAvailSchOn()

        z.addForscriptSchSingleZone()

        z.addEMSProgramsBase()
        z.addEMSOutputVariableBase()

        z.addGlobVarListSingleZone()
        z.addEMSSensorsSingleZone()
        z.addEMSActuatorsSingleZone()
        z.addEMSProgramsSingleZone()
        z.addEMSPCMBase()
        z.addSimplifiedOutputVariables()

        z.saveACCIM()

    z = ACCIM_Main.ACCIMobj()
    z.inputdataSingleZone()
    z.genIDFSingleZone()


def addAccisSingleZoneSimplifiedEp94():
    """Add SingleZone ACCIS with simplified outputs."""
    import sim.ACCIM_Main as ACCIM_Main

    from os import listdir

    filelist = ([file for file in listdir() if file.endswith('.idf')
                 and not file.endswith('_pymod.idf')])

    filelist = ([file.split('.idf')[0] for file in filelist])

    for file in filelist:
        z = ACCIM_Main.ACCIMobj_SingleZone_ep94(file)

        z.setComfFieldsPeople()
        z.addOpTempTherm()
        z.addBaseSchedules()
        z.setAvailSchOn()

        z.addForscriptSchSingleZone()

        z.addEMSProgramsBase()
        z.addEMSOutputVariableBase()

        z.addGlobVarListSingleZone()
        z.addEMSSensorsSingleZone()
        z.addEMSActuatorsSingleZone()
        z.addEMSProgramsSingleZone()
        z.addEMSPCMBase()
        z.addSimplifiedOutputVariables()

        z.saveACCIM()

    z = ACCIM_Main.ACCIMobj()
    z.inputdataSingleZone()
    z.genIDFSingleZone()


def addAccisMultipleZoneEp91():
    """Add MultipleZone ACCIS."""
    import sim.ACCIM_Main as ACCIM_Main

    from os import listdir

    filelist = ([file for file in listdir() if file.endswith('.idf')
                 and not file.endswith('_pymod.idf')])

    filelist = ([file.split('.idf')[0] for file in filelist])

    for file in filelist:
        z = ACCIM_Main.ACCIMobj_MultipleZone_ep91(file)

        z.setComfFieldsPeople()
        z.addOpTempTherm()
        z.addBaseSchedules()
        z.setAvailSchOn()

        z.addMultipleZoneSch()
        z.addCurveObj()
        z.addDetHVACobjEp91()
        z.addForscriptSchMultipleZone()
        z.checkVentIsOn()

        z.addEMSProgramsBase()
        z.addEMSOutputVariableBase()

        z.addGlobVarListMultipleZone()
        z.addEMSSensorsMultipleZone()
        z.addEMSActuatorsMultipleZone()
        z.addEMSProgramsMultipleZone()
        z.addEMSPCMBase()
        z.addEMSOutputVariableMultipleZone()
        z.addOutputVariablesMultipleZone()

        z.saveACCIM()

    z = ACCIM_Main.ACCIMobj()
    z.inputdataMultipleZone()
    z.genIDFMultipleZone()


def addAccisMultipleZoneEp94():
    """Add MultipleZone ACCIS."""
    import sim.ACCIM_Main as ACCIM_Main

    from os import listdir

    filelist = ([file for file in listdir() if file.endswith('.idf')
                 and not file.endswith('_pymod.idf')])

    filelist = ([file.split('.idf')[0] for file in filelist])

    for file in filelist:
        z = ACCIM_Main.ACCIMobj_MultipleZone_ep94(file)

        z.setComfFieldsPeople()
        z.addOpTempTherm()
        z.addBaseSchedules()
        z.setAvailSchOn()

        z.addMultipleZoneSch()
        z.addCurveObj()
        z.addDetHVACobjEp94()
        z.addForscriptSchMultipleZone()
        z.checkVentIsOn()

        z.addEMSProgramsBase()
        z.addEMSOutputVariableBase()

        z.addGlobVarListMultipleZone()
        z.addEMSSensorsMultipleZone()
        z.addEMSActuatorsMultipleZone()
        z.addEMSProgramsMultipleZone()
        z.addEMSPCMBase()
        z.addEMSOutputVariableMultipleZone()
        z.addOutputVariablesMultipleZone()

        z.saveACCIM()

    z = ACCIM_Main.ACCIMobj()
    z.inputdataMultipleZone()
    z.genIDFMultipleZone()


def addAccisMultipleZoneTimestepEp91():
    """Add MultipleZone ACCIS with timestep output data frecuency."""
    import sim.ACCIM_Main as ACCIM_Main

    from os import listdir

    filelist = ([file for file in listdir() if file.endswith('.idf')
                 and not file.endswith('_pymod.idf')])

    filelist = ([file.split('.idf')[0] for file in filelist])

    for file in filelist:
        z = ACCIM_Main.ACCIMobj_MultipleZone_ep91(file)

        z.setComfFieldsPeople()
        z.addOpTempTherm()
        z.addBaseSchedules()
        z.setAvailSchOn()

        z.addMultipleZoneSch()
        z.addCurveObj()
        z.addDetHVACobjEp91()
        z.addForscriptSchMultipleZone()
        z.checkVentIsOn()

        z.addEMSProgramsBase()
        z.addEMSOutputVariableBase()

        z.addGlobVarListMultipleZone()
        z.addEMSSensorsMultipleZone()
        z.addEMSActuatorsMultipleZone()
        z.addEMSProgramsMultipleZone()
        z.addEMSPCMBase()
        z.addEMSOutputVariableMultipleZone()
        z.addOutputVariablesMultipleZone()
        z.addOutputVariablesTimestep()

        z.saveACCIM()

    z = ACCIM_Main.ACCIMobj()
    z.inputdataMultipleZone()
    z.genIDFMultipleZone()


def addAccisMultipleZoneTimestepEp94():
    """Add MultipleZone ACCIS with timestep output data frecuency."""
    import sim.ACCIM_Main as ACCIM_Main

    from os import listdir

    filelist = ([file for file in listdir() if file.endswith('.idf')
                 and not file.endswith('_pymod.idf')])

    filelist = ([file.split('.idf')[0] for file in filelist])

    for file in filelist:
        z = ACCIM_Main.ACCIMobj_MultipleZone_ep94(file)

        z.setComfFieldsPeople()
        z.addOpTempTherm()
        z.addBaseSchedules()
        z.setAvailSchOn()

        z.addMultipleZoneSch()
        z.addCurveObj()
        z.addDetHVACobjEp94()
        z.addForscriptSchMultipleZone()
        z.checkVentIsOn()

        z.addEMSProgramsBase()
        z.addEMSOutputVariableBase()

        z.addGlobVarListMultipleZone()
        z.addEMSSensorsMultipleZone()
        z.addEMSActuatorsMultipleZone()
        z.addEMSProgramsMultipleZone()
        z.addEMSPCMBase()
        z.addEMSOutputVariableMultipleZone()
        z.addOutputVariablesMultipleZone()
        z.addOutputVariablesTimestep()

        z.saveACCIM()

    z = ACCIM_Main.ACCIMobj()
    z.inputdataMultipleZone()
    z.genIDFMultipleZone()


def addAccisMultipleZoneSimplifiedEp91():
    """Add MultipleZone ACCIS with simplified output."""
    import sim.ACCIM_Main as ACCIM_Main

    from os import listdir

    filelist = ([file for file in listdir() if file.endswith('.idf')
                 and not file.endswith('_pymod.idf')])

    filelist = ([file.split('.idf')[0] for file in filelist])

    for file in filelist:
        z = ACCIM_Main.ACCIMobj_MultipleZone_ep91(file)

        z.setComfFieldsPeople()
        z.addOpTempTherm()
        z.addBaseSchedules()
        z.setAvailSchOn()

        z.addMultipleZoneSch()
        z.addCurveObj()
        z.addDetHVACobjEp91()
        z.addForscriptSchMultipleZone()
        z.checkVentIsOn()

        z.addEMSProgramsBase()
        z.addEMSOutputVariableBase()

        z.addGlobVarListMultipleZone()
        z.addEMSSensorsMultipleZone()
        z.addEMSActuatorsMultipleZone()
        z.addEMSProgramsMultipleZone()
        z.addEMSPCMBase()
        z.addEMSOutputVariableMultipleZone()
        z.addSimplifiedOutputVariables()

        z.saveACCIM()

    z = ACCIM_Main.ACCIMobj()
    z.inputdataMultipleZone()
    z.genIDFMultipleZone()


def addAccisMultipleZoneSimplifiedEp94():
    """Add MultipleZone ACCIS with simplified output."""
    import sim.ACCIM_Main as ACCIM_Main

    from os import listdir

    filelist = ([file for file in listdir() if file.endswith('.idf')
                 and not file.endswith('_pymod.idf')])

    filelist = ([file.split('.idf')[0] for file in filelist])

    for file in filelist:
        z = ACCIM_Main.ACCIMobj_MultipleZone_ep94(file)

        z.setComfFieldsPeople()
        z.addOpTempTherm()
        z.addBaseSchedules()
        z.setAvailSchOn()

        z.addMultipleZoneSch()
        z.addCurveObj()
        z.addDetHVACobjEp94()
        z.addForscriptSchMultipleZone()
        z.checkVentIsOn()

        z.addEMSProgramsBase()
        z.addEMSOutputVariableBase()

        z.addGlobVarListMultipleZone()
        z.addEMSSensorsMultipleZone()
        z.addEMSActuatorsMultipleZone()
        z.addEMSProgramsMultipleZone()
        z.addEMSPCMBase()
        z.addEMSOutputVariableMultipleZone()
        z.addSimplifiedOutputVariables()

        z.saveACCIM()

    z = ACCIM_Main.ACCIMobj()
    z.inputdataMultipleZone()
    z.genIDFMultipleZone()
