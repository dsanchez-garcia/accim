def getEnergyConsumpTable():
    from accim.data import main
    
    z=main.Table()
    z.EnergyConsumptionTable()

# getEnergyConsumpTable()
