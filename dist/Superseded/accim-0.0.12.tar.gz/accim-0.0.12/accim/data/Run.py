def getEnergyConsumpTable():
    from accim.data import Main
    
    z=Main.Table()
    z.EnergyConsumptionTable()

# getEnergyConsumpTable()
