class ACCIMobj:
    """ACCIM Object."""

    from os import listdir
    import numpy

    from sim.ACCIM_IDFgeneration import inputdataFullAC
    from sim.ACCIM_IDFgeneration import inputdataMixedMode
    from sim.ACCIM_IDFgeneration import genIDFFullAC
    from sim.ACCIM_IDFgeneration import genIDFMixedMode

    from sim.ACCIM_Base import setComfFieldsPeople
    from sim.ACCIM_Base import addOpTempTherm
    from sim.ACCIM_Base import addBaseSchedules
    from sim.ACCIM_Base import setAvailSchOn
    from sim.ACCIM_Base import saveACCIM

    from sim.ACCIM_Base_EMS import addEMSProgramsBase
    from sim.ACCIM_Base_EMS import addEMSPCMBase
    from sim.ACCIM_Base_EMS import addEMSOutputVariableBase
    from sim.ACCIM_Base_EMS import addOutputVariablesTimestep
    from sim.ACCIM_Base_EMS import addSimplifiedOutputVariables

    pass


class ACCIMobj_FullAC_ep91(ACCIMobj):
    """Full AC ACCIM object."""

    from sim.ACCIM_FullAC import addForscriptSchFullAC

    from sim.ACCIM_FullAC_EMS import addGlobVarListFullAC
    from sim.ACCIM_FullAC_EMS import addEMSSensorsFullAC
    from sim.ACCIM_FullAC_EMS import addEMSActuatorsFullAC
    from sim.ACCIM_FullAC_EMS import addEMSProgramsFullAC
    from sim.ACCIM_FullAC_EMS import addOutputVariablesFullAC

    def __init__(self, filename_temp):
        from eppy import modeleditor
        from eppy.modeleditor import IDF

        iddfile = "C:/EnergyPlusV9-1-0/Energy+.idd"
        IDF.setiddname(iddfile)

        fname1 = filename_temp + ".idf"
        self.idf0 = IDF(fname1)
        self.idf0.savecopy(filename_temp + "_pymod.idf")

        self.filename = filename_temp + "_pymod"
        fname1 = self.filename + ".idf"
        self.idf1 = IDF(fname1)
        self.filename = filename_temp + "_pymod"

        print(self.filename)

        self.zonenames_orig = [zone.Name for zone in self.idf1.idfobjects["ZONE"]]
        # print(self.zonenames_orig)

        self.zonenames = [
            sub.replace(":", "_")
            for sub in ([zone.Name for zone in self.idf1.idfobjects["ZONE"]])
        ]
        # print(self.zonenames)


class ACCIMobj_MixedMode_ep91(ACCIMobj):
    """Mixed Mode ACCIM object."""

    from sim.ACCIM_MixedMode import addMixedModeSch
    from sim.ACCIM_MixedMode import addCurveObj
    from sim.ACCIM_MixedMode import addDetHVACobjEp91
    from sim.ACCIM_MixedMode import addForscriptSchMixedMode
    from sim.ACCIM_MixedMode import checkVentIsOn

    from sim.ACCIM_MixedMode_EMS import addGlobVarListMixedMode
    from sim.ACCIM_MixedMode_EMS import addEMSSensorsMixedMode
    from sim.ACCIM_MixedMode_EMS import addEMSActuatorsMixedMode
    from sim.ACCIM_MixedMode_EMS import addEMSProgramsMixedMode
    from sim.ACCIM_MixedMode_EMS import addEMSOutputVariableMixedMode
    from sim.ACCIM_MixedMode_EMS import addOutputVariablesMixedMode

    def __init__(self, filename_temp):
        from eppy import modeleditor
        from eppy.modeleditor import IDF

        iddfile = "C:/EnergyPlusV9-1-0/Energy+.idd"
        IDF.setiddname(iddfile)

        fname1 = filename_temp + ".idf"
        self.idf0 = IDF(fname1)
        self.idf0.savecopy(filename_temp + "_pymod.idf")

        self.filename = filename_temp + "_pymod"
        fname1 = self.filename + ".idf"
        self.idf1 = IDF(fname1)
        self.filename = filename_temp + "_pymod"

        print(self.filename)

        self.zonenames_orig = [zone.Name for zone in self.idf1.idfobjects["ZONE"]]
        # print(self.zonenames_orig)

        self.zonenames = [
            sub.replace(":", "_")
            for sub in ([zone.Name for zone in self.idf1.idfobjects["ZONE"]])
        ]
        # print(self.zonenames)

        self.windownamelist_orig = [
            window.Name
            for window in self.idf1.idfobjects[
                "AirflowNetwork:MultiZone:Component:DetailedOpening"
            ]
            if window.Name.endswith("_Win")
        ]
        print(self.windownamelist_orig)
        self.windownamelist_orig_split = [
            i.split("_") for i in self.windownamelist_orig
        ]
        # print(self.windownamelist_orig_split)

        self.windownamelist = [
            sub.replace(":", "_")
            for sub in (
                [
                    window.Name
                    for window in self.idf1.idfobjects[
                        "AirflowNetwork:MultiZone:Component:DetailedOpening"
                    ]
                    if window.Name.endswith("_Win")
                ]
            )
        ]
        # print(self.windownamelist)


class ACCIMobj_FullAC_ep94(ACCIMobj):
    """Full AC ACCIM object."""

    from sim.ACCIM_FullAC import addForscriptSchFullAC

    from sim.ACCIM_FullAC_EMS import addGlobVarListFullAC
    from sim.ACCIM_FullAC_EMS import addEMSSensorsFullAC
    from sim.ACCIM_FullAC_EMS import addEMSActuatorsFullAC
    from sim.ACCIM_FullAC_EMS import addEMSProgramsFullAC
    from sim.ACCIM_FullAC_EMS import addOutputVariablesFullAC

    def __init__(self, filename_temp):
        from eppy import modeleditor
        from eppy.modeleditor import IDF

        iddfile = "C:/EnergyPlusV9-4-0/Energy+.idd"
        IDF.setiddname(iddfile)

        fname1 = filename_temp + ".idf"
        self.idf0 = IDF(fname1)
        self.idf0.savecopy(filename_temp + "_pymod.idf")

        self.filename = filename_temp + "_pymod"
        fname1 = self.filename + ".idf"
        self.idf1 = IDF(fname1)
        self.filename = filename_temp + "_pymod"

        print(self.filename)

        self.zonenames_orig = [zone.Name for zone in self.idf1.idfobjects["ZONE"]]
        # print(self.zonenames_orig)

        self.zonenames = [
            sub.replace(":", "_")
            for sub in ([zone.Name for zone in self.idf1.idfobjects["ZONE"]])
        ]
        # print(self.zonenames)


class ACCIMobj_MixedMode_ep94(ACCIMobj):
    """Mixed Mode ACCIM object."""

    from sim.ACCIM_MixedMode import addMixedModeSch
    from sim.ACCIM_MixedMode import addCurveObj
    from sim.ACCIM_MixedMode import addDetHVACobjEp94
    from sim.ACCIM_MixedMode import addForscriptSchMixedMode
    from sim.ACCIM_MixedMode import checkVentIsOn

    from sim.ACCIM_MixedMode_EMS import addGlobVarListMixedMode
    from sim.ACCIM_MixedMode_EMS import addEMSSensorsMixedMode
    from sim.ACCIM_MixedMode_EMS import addEMSActuatorsMixedMode
    from sim.ACCIM_MixedMode_EMS import addEMSProgramsMixedMode
    from sim.ACCIM_MixedMode_EMS import addEMSOutputVariableMixedMode
    from sim.ACCIM_MixedMode_EMS import addOutputVariablesMixedMode

    def __init__(self, filename_temp):
        from eppy import modeleditor
        from eppy.modeleditor import IDF

        iddfile = "C:/EnergyPlusV9-4-0/Energy+.idd"
        IDF.setiddname(iddfile)

        fname1 = filename_temp + ".idf"
        self.idf0 = IDF(fname1)
        self.idf0.savecopy(filename_temp + "_pymod.idf")

        self.filename = filename_temp + "_pymod"
        fname1 = self.filename + ".idf"
        self.idf1 = IDF(fname1)
        self.filename = filename_temp + "_pymod"

        print(self.filename)

        self.zonenames_orig = [zone.Name for zone in self.idf1.idfobjects["ZONE"]]
        # print(self.zonenames_orig)

        self.zonenames = [
            sub.replace(":", "_")
            for sub in ([zone.Name for zone in self.idf1.idfobjects["ZONE"]])
        ]
        # print(self.zonenames)

        self.windownamelist_orig = [
            window.Name
            for window in self.idf1.idfobjects[
                "AirflowNetwork:MultiZone:Component:DetailedOpening"
            ]
            if window.Name.endswith("_Win")
        ]
        print(self.windownamelist_orig)
        self.windownamelist_orig_split = [
            i.split("_") for i in self.windownamelist_orig
        ]
        # print(self.windownamelist_orig_split)

        self.windownamelist = [
            sub.replace(":", "_")
            for sub in (
                [
                    window.Name
                    for window in self.idf1.idfobjects[
                        "AirflowNetwork:MultiZone:Component:DetailedOpening"
                    ]
                    if window.Name.endswith("_Win")
                ]
            )
        ]
        # print(self.windownamelist)
