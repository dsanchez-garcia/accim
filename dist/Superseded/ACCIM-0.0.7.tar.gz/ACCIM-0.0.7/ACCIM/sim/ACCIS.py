"""
Run any of the functions below to add the ACCIS.

These functions transform fixed setpoint temperature
building energy models into adaptive setpoint temperature energy models
by addingthe Adaptive Comfort Control Implementation Script (ACCIS)
"""


def addAccisFullACep91():
    """Add Full AC ACCIS."""
    import sim.ACCIM_Main as ACCIM_Main
    from os import listdir

    filelist = [
        file
        for file in listdir()
        if file.endswith(".idf") and not file.endswith("_pymod.idf")
    ]

    filelist = [file.split(".idf")[0] for file in filelist]

    for file in filelist:
        z = ACCIM_Main.ACCIMobj_FullAC_ep91(file)

        z.setComfFieldsPeople()
        z.addOpTempTherm()
        z.addBaseSchedules()
        z.setAvailSchOn()

        z.addForscriptSchFullAC()

        z.addEMSProgramsBase()
        z.addEMSOutputVariableBase()

        z.addGlobVarListFullAC()
        z.addEMSSensorsFullAC()
        z.addEMSActuatorsFullAC()
        z.addEMSProgramsFullAC()
        z.addEMSPCMBase()
        z.addOutputVariablesFullAC()

        z.saveACCIM()

    z = ACCIM_Main.ACCIMobj()
    z.inputdataFullAC()
    z.genIDFFullAC()


def addAccisFullACep94():
    """Add Full AC ACCIS."""
    import sim.ACCIM_Main as ACCIM_Main

    from os import listdir

    filelist = [
        file
        for file in listdir()
        if file.endswith(".idf") and not file.endswith("_pymod.idf")
    ]

    filelist = [file.split(".idf")[0] for file in filelist]

    for file in filelist:
        z = ACCIM_Main.ACCIMobj_FullAC_ep94(file)

        z.setComfFieldsPeople()
        z.addOpTempTherm()
        z.addBaseSchedules()
        z.setAvailSchOn()

        z.addForscriptSchFullAC()

        z.addEMSProgramsBase()
        z.addEMSOutputVariableBase()

        z.addGlobVarListFullAC()
        z.addEMSSensorsFullAC()
        z.addEMSActuatorsFullAC()
        z.addEMSProgramsFullAC()
        z.addEMSPCMBase()
        z.addOutputVariablesFullAC()

        z.saveACCIM()

    z = ACCIM_Main.ACCIMobj()
    z.inputdataFullAC()
    z.genIDFFullAC()


def addAccisFullACTimestepEp91():
    """Add Full AC ACCIS with timestep output data frecuency."""
    import sim.ACCIM_Main as ACCIM_Main

    from os import listdir

    filelist = [
        file
        for file in listdir()
        if file.endswith(".idf") and not file.endswith("_pymod.idf")
    ]

    filelist = [file.split(".idf")[0] for file in filelist]

    for file in filelist:
        z = ACCIM_Main.ACCIMobj_FullAC_ep91(file)

        z.setComfFieldsPeople()
        z.addOpTempTherm()
        z.addBaseSchedules()
        z.setAvailSchOn()

        z.addForscriptSchFullAC()

        z.addEMSProgramsBase()
        z.addEMSOutputVariableBase()

        z.addGlobVarListFullAC()
        z.addEMSSensorsFullAC()
        z.addEMSActuatorsFullAC()
        z.addEMSProgramsFullAC()
        z.addEMSPCMBase()
        z.addOutputVariablesFullAC()
        z.addOutputVariablesTimestep()

        z.saveACCIM()

    z = ACCIM_Main.ACCIMobj()
    z.inputdataFullAC()
    z.genIDFFullAC()


def addAccisFullACTimestepEp94():
    """Add Full AC ACCIS with timestep output data frecuency."""
    import sim.ACCIM_Main as ACCIM_Main

    from os import listdir

    filelist = [
        file
        for file in listdir()
        if file.endswith(".idf") and not file.endswith("_pymod.idf")
    ]

    filelist = [file.split(".idf")[0] for file in filelist]

    for file in filelist:
        z = ACCIM_Main.ACCIMobj_FullAC_ep94(file)

        z.setComfFieldsPeople()
        z.addOpTempTherm()
        z.addBaseSchedules()
        z.setAvailSchOn()

        z.addForscriptSchFullAC()

        z.addEMSProgramsBase()
        z.addEMSOutputVariableBase()

        z.addGlobVarListFullAC()
        z.addEMSSensorsFullAC()
        z.addEMSActuatorsFullAC()
        z.addEMSProgramsFullAC()
        z.addEMSPCMBase()
        z.addOutputVariablesFullAC()
        z.addOutputVariablesTimestep()

        z.saveACCIM()

    z = ACCIM_Main.ACCIMobj()
    z.inputdataFullAC()
    z.genIDFFullAC()


def addAccisFullACSimplifiedEp91():
    """Add Full AC ACCIS with simplified outputs."""
    import sim.ACCIM_Main as ACCIM_Main

    from os import listdir

    filelist = [
        file
        for file in listdir()
        if file.endswith(".idf") and not file.endswith("_pymod.idf")
    ]

    filelist = [file.split(".idf")[0] for file in filelist]

    for file in filelist:
        z = ACCIM_Main.ACCIMobj_FullAC_ep91(file)

        z.setComfFieldsPeople()
        z.addOpTempTherm()
        z.addBaseSchedules()
        z.setAvailSchOn()

        z.addForscriptSchFullAC()

        z.addEMSProgramsBase()
        z.addEMSOutputVariableBase()

        z.addGlobVarListFullAC()
        z.addEMSSensorsFullAC()
        z.addEMSActuatorsFullAC()
        z.addEMSProgramsFullAC()
        z.addEMSPCMBase()
        z.addSimplifiedOutputVariables()

        z.saveACCIM()

    z = ACCIM_Main.ACCIMobj()
    z.inputdataFullAC()
    z.genIDFFullAC()


def addAccisFullACSimplifiedEp94():
    """Add Full AC ACCIS with simplified outputs."""
    import sim.ACCIM_Main as ACCIM_Main

    from os import listdir

    filelist = [
        file
        for file in listdir()
        if file.endswith(".idf") and not file.endswith("_pymod.idf")
    ]

    filelist = [file.split(".idf")[0] for file in filelist]

    for file in filelist:
        z = ACCIM_Main.ACCIMobj_FullAC_ep94(file)

        z.setComfFieldsPeople()
        z.addOpTempTherm()
        z.addBaseSchedules()
        z.setAvailSchOn()

        z.addForscriptSchFullAC()

        z.addEMSProgramsBase()
        z.addEMSOutputVariableBase()

        z.addGlobVarListFullAC()
        z.addEMSSensorsFullAC()
        z.addEMSActuatorsFullAC()
        z.addEMSProgramsFullAC()
        z.addEMSPCMBase()
        z.addSimplifiedOutputVariables()

        z.saveACCIM()

    z = ACCIM_Main.ACCIMobj()
    z.inputdataFullAC()
    z.genIDFFullAC()


def addAccisMixedModeEp91():
    """Add Mixed Mode ACCIS."""
    import sim.ACCIM_Main as ACCIM_Main

    from os import listdir

    filelist = [
        file
        for file in listdir()
        if file.endswith(".idf") and not file.endswith("_pymod.idf")
    ]

    filelist = [file.split(".idf")[0] for file in filelist]

    for file in filelist:
        z = ACCIM_Main.ACCIMobj_MixedMode_ep91(file)

        z.setComfFieldsPeople()
        z.addOpTempTherm()
        z.addBaseSchedules()
        z.setAvailSchOn()

        z.addMixedModeSch()
        z.addCurveObj()
        z.addDetHVACobjEp91()
        z.addForscriptSchMixedMode()
        z.checkVentIsOn()

        z.addEMSProgramsBase()
        z.addEMSOutputVariableBase()

        z.addGlobVarListMixedMode()
        z.addEMSSensorsMixedMode()
        z.addEMSActuatorsMixedMode()
        z.addEMSProgramsMixedMode()
        z.addEMSPCMBase()
        z.addEMSOutputVariableMixedMode()
        z.addOutputVariablesMixedMode()

        z.saveACCIM()

    z = ACCIM_Main.ACCIMobj()
    z.inputdataMixedMode()
    z.genIDFMixedMode()


def addAccisMixedModeEp94():
    """Add Mixed Mode ACCIS."""
    import sim.ACCIM_Main as ACCIM_Main

    from os import listdir

    filelist = [
        file
        for file in listdir()
        if file.endswith(".idf") and not file.endswith("_pymod.idf")
    ]

    filelist = [file.split(".idf")[0] for file in filelist]

    for file in filelist:
        z = ACCIM_Main.ACCIMobj_MixedMode_ep94(file)

        z.setComfFieldsPeople()
        z.addOpTempTherm()
        z.addBaseSchedules()
        z.setAvailSchOn()

        z.addMixedModeSch()
        z.addCurveObj()
        z.addDetHVACobjEp94()
        z.addForscriptSchMixedMode()
        z.checkVentIsOn()

        z.addEMSProgramsBase()
        z.addEMSOutputVariableBase()

        z.addGlobVarListMixedMode()
        z.addEMSSensorsMixedMode()
        z.addEMSActuatorsMixedMode()
        z.addEMSProgramsMixedMode()
        z.addEMSPCMBase()
        z.addEMSOutputVariableMixedMode()
        z.addOutputVariablesMixedMode()

        z.saveACCIM()

    z = ACCIM_Main.ACCIMobj()
    z.inputdataMixedMode()
    z.genIDFMixedMode()


def addAccisMixedModeTimestepEp91():
    """Add Mixed Mode ACCIS with timestep output data frecuency."""
    import sim.ACCIM_Main as ACCIM_Main

    from os import listdir

    filelist = [
        file
        for file in listdir()
        if file.endswith(".idf") and not file.endswith("_pymod.idf")
    ]

    filelist = [file.split(".idf")[0] for file in filelist]

    for file in filelist:
        z = ACCIM_Main.ACCIMobj_MixedMode_ep91(file)

        z.setComfFieldsPeople()
        z.addOpTempTherm()
        z.addBaseSchedules()
        z.setAvailSchOn()

        z.addMixedModeSch()
        z.addCurveObj()
        z.addDetHVACobjEp91()
        z.addForscriptSchMixedMode()
        z.checkVentIsOn()

        z.addEMSProgramsBase()
        z.addEMSOutputVariableBase()

        z.addGlobVarListMixedMode()
        z.addEMSSensorsMixedMode()
        z.addEMSActuatorsMixedMode()
        z.addEMSProgramsMixedMode()
        z.addEMSPCMBase()
        z.addEMSOutputVariableMixedMode()
        z.addOutputVariablesMixedMode()
        z.addOutputVariablesTimestep()

        z.saveACCIM()

    z = ACCIM_Main.ACCIMobj()
    z.inputdataMixedMode()
    z.genIDFMixedMode()


def addAccisMixedModeTimestepEp94():
    """Add Mixed Mode ACCIS with timestep output data frecuency."""
    import sim.ACCIM_Main as ACCIM_Main

    from os import listdir

    filelist = [
        file
        for file in listdir()
        if file.endswith(".idf") and not file.endswith("_pymod.idf")
    ]

    filelist = [file.split(".idf")[0] for file in filelist]

    for file in filelist:
        z = ACCIM_Main.ACCIMobj_MixedMode_ep94(file)

        z.setComfFieldsPeople()
        z.addOpTempTherm()
        z.addBaseSchedules()
        z.setAvailSchOn()

        z.addMixedModeSch()
        z.addCurveObj()
        z.addDetHVACobjEp94()
        z.addForscriptSchMixedMode()
        z.checkVentIsOn()

        z.addEMSProgramsBase()
        z.addEMSOutputVariableBase()

        z.addGlobVarListMixedMode()
        z.addEMSSensorsMixedMode()
        z.addEMSActuatorsMixedMode()
        z.addEMSProgramsMixedMode()
        z.addEMSPCMBase()
        z.addEMSOutputVariableMixedMode()
        z.addOutputVariablesMixedMode()
        z.addOutputVariablesTimestep()

        z.saveACCIM()

    z = ACCIM_Main.ACCIMobj()
    z.inputdataMixedMode()
    z.genIDFMixedMode()


def addAccisMixedModeSimplifiedEp91():
    """Add Mixed Mode ACCIS with simplified output."""
    import sim.ACCIM_Main as ACCIM_Main

    from os import listdir

    filelist = [
        file
        for file in listdir()
        if file.endswith(".idf") and not file.endswith("_pymod.idf")
    ]

    filelist = [file.split(".idf")[0] for file in filelist]

    for file in filelist:
        z = ACCIM_Main.ACCIMobj_MixedMode_ep91(file)

        z.setComfFieldsPeople()
        z.addOpTempTherm()
        z.addBaseSchedules()
        z.setAvailSchOn()

        z.addMixedModeSch()
        z.addCurveObj()
        z.addDetHVACobjEp91()
        z.addForscriptSchMixedMode()
        z.checkVentIsOn()

        z.addEMSProgramsBase()
        z.addEMSOutputVariableBase()

        z.addGlobVarListMixedMode()
        z.addEMSSensorsMixedMode()
        z.addEMSActuatorsMixedMode()
        z.addEMSProgramsMixedMode()
        z.addEMSPCMBase()
        z.addEMSOutputVariableMixedMode()
        z.addSimplifiedOutputVariables()

        z.saveACCIM()

    z = ACCIM_Main.ACCIMobj()
    z.inputdataMixedMode()
    z.genIDFMixedMode()


def addAccisMixedModeSimplifiedEp94():
    """Add Mixed Mode ACCIS with simplified output."""
    import sim.ACCIM_Main as ACCIM_Main

    from os import listdir

    filelist = [
        file
        for file in listdir()
        if file.endswith(".idf") and not file.endswith("_pymod.idf")
    ]

    filelist = [file.split(".idf")[0] for file in filelist]

    for file in filelist:
        z = ACCIM_Main.ACCIMobj_MixedMode_ep94(file)

        z.setComfFieldsPeople()
        z.addOpTempTherm()
        z.addBaseSchedules()
        z.setAvailSchOn()

        z.addMixedModeSch()
        z.addCurveObj()
        z.addDetHVACobjEp94()
        z.addForscriptSchMixedMode()
        z.checkVentIsOn()

        z.addEMSProgramsBase()
        z.addEMSOutputVariableBase()

        z.addGlobVarListMixedMode()
        z.addEMSSensorsMixedMode()
        z.addEMSActuatorsMixedMode()
        z.addEMSProgramsMixedMode()
        z.addEMSPCMBase()
        z.addEMSOutputVariableMixedMode()
        z.addSimplifiedOutputVariables()

        z.saveACCIM()

    z = ACCIM_Main.ACCIMobj()
    z.inputdataMixedMode()
    z.genIDFMixedMode()
