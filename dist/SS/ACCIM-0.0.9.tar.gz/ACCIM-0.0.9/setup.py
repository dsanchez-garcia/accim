from setuptools import setup, find_packages
import pathlib


# The directory containing this file
# HERE = pathlib.Path(__file__).parent

# The text of the README file
# README = (HERE / "README.md").read_text()

setup(
      name='ACCIM',
      version='0.0.9',
      description="""Transforms fixed setpoint temperature building energy
          models into adaptive setpoint temperature energy models by adding
          the Adaptive Comfort Control Implementation Script (ACCIS)""",
      # long_description=README,
      long_description_content_type="text/markdown",
      author='Daniel Sánchez-García',
      author_email='dsanchez7@us.es',
      license="MIT",
      classifiers=[
          'License :: OSI Approved :: MIT License',
          'Programming Language :: Python :: 3',
          'Programming Language :: Python :: 3.8',
          ],
      packages=find_packages(),
      # include_package_data=True,
      # install_requires=["eppy", ""],
      scripts=['bin/accis.py']
      )
