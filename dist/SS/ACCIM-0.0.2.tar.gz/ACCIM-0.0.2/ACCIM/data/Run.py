def getEnergyConsumpTable():
    from ACCIM.data import Main
    
    z=Main.Table()
    z.EnergyConsumptionTable()

# getEnergyConsumpTable()
