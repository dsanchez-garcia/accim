from accim.data.data_postprocessing import rename_epw_files
z = rename_epw_files(
    # filelist=['RCP26_2050_Nagasaki_JA.epw']
)